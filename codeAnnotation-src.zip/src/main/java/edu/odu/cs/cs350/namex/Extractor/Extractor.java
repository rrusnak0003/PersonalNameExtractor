package edu.odu.cs.cs350.namex.Extractor;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;

public class Extractor {

	public static void main(String[] args){
		
		Trainer mainTrainer = new Trainer();	
		//Unsure of the plans for the procedure of working with training data, change anything you see fit.
		//Assuming that .prepareTrainingMaterials will handle selection of .arff file or new instances?
		mainTrainer.prepareTrainingMaterials();
		mainTrainer.train();
		
		//Create a temporary object file for the trained learning machine
		File tempFile = null;
		try {
			tempFile = File.createTempFile("tempLearningMachine",".ser");
		} catch (IOException e) {
            System.err.println( "Error: " + tempFile + " could not be opened" );
            System.exit( 2 );
		}
		
		outputLearningMachine(mainTrainer.getLearningMachine(), "tempLearningMachine.ser");
		
		BufferedReader inputStr = new BufferedReader(new InputStreamReader(System.in));
		String toProcess = inputStr.toString();
		
		String markedUp = markPersonalNames(toProcess);
		System.out.println(markedUp);
		tempFile.deleteOnExit();
	}
	
	
    /**
     * Searches through a given string to find names from an ArrayList, if found, names are marked up with <PER></PER> tags
     * 
     * @param textBlock: A block of text to process, string format.
     * @return processed: The marked-up string after being processed.
     **/
	public static String markPersonalNames(String textBlock){
		
		//Read in the saved LearningMachine from Trainer and assign it to a new LearningMachine
		LearningMachine catalogerBrain = inputLearningMachine("tempLearningMachine.ser");
		
		Cataloger mainCataloger = new Cataloger(catalogerBrain);	//Create a cataloger from the LearningMachine built above
		mainCataloger.identifyNamesIn(textBlock);					//Creates a list of names from the text block 
		
		String[] nameList = new String[mainCataloger.getNameList().size()];	//Create a copy of the nameList obtained by the Cataloger
		mainCataloger.getNameList().toArray(nameList);
		
		String markedUp = textBlock;
		for(int i = 0; i < nameList.length; i++){					//Runs through the list of names
			String marking = "<PER>" + nameList[i] + "</PER>";		//For each name in the list, create a string with <PER> tags surrounding it
			markedUp = markedUp.replace(nameList[i], marking);		//Replace the name in the textblock with the new, marked up version.
			}
		return markedUp;
	}
	
	
	/**
	 * Writes the learning machine with mainTrainer to a temporary file
	 * 
	 * @param lm: Desired learning machine to write to file.
	 * @param tempfile: name of the file that you want to write to.
	 **/
	public static void outputLearningMachine(LearningMachine lm, String tempfile){
		FileOutputStream fileOut = null;
		
		try {
			fileOut = new FileOutputStream (tempfile);
		} catch (FileNotFoundException e) {
            System.err.println( "Error: " + tempfile + " could not be opened" );
            System.exit( 2 );
		}
		
		ObjectOutputStream out = null;
		
		try {
			out = new ObjectOutputStream (fileOut);
		} catch (IOException e) {
            System.err.println( "Error: " + fileOut + " could not be opened" );
            System.exit( 2 );
		}
		
		try {
			out.writeObject (lm);
		} catch (IOException e) {
            System.err.println( "Error: " + out + " could not be opened" );
            System.exit( 2 );
		}
		
		try {
			out.close();
		} catch (IOException e) {
            System.err.println( "Error: " + out + " could not be found" );
            System.exit( 2 );
		}
	}
	
	/**
	 * Reads a learning machine from a temp file.
	 * 
	 * @param tempfile: name of the file that you want to write to.
	 * @return brain: the learning machine that was loaded.
	 **/
	public static LearningMachine inputLearningMachine(String tempfile){
		LearningMachine brain = null;
		FileInputStream fileIn = null;
		try {
			fileIn = new FileInputStream (tempfile);
		} catch (FileNotFoundException e) {
			System.err.println( "Error: tempLearningMachine.ser could not be opened" );
            System.exit( 2 );
		}
		
		ObjectInputStream in = null;
		try {
			in = new ObjectInputStream (fileIn);
		} catch (IOException e) {
            System.err.println( "Error: " + fileIn+ " could not be opened" );
            System.exit( 2 );
		}
		
		try {
			brain = (LearningMachine) in.readObject ();
		} catch (ClassNotFoundException e) {
            System.err.println( "LearningMachine class could not be found" );
            System.exit( 2 );
		} catch (IOException e) {
            System.err.println( "Error: " + in + " could not be opened" );
            System.exit( 2 );
		}
		
		try {
			in.close();
		} catch (IOException e) {
			System.err.println( "Error: " + in + " could not be found" );
            System.exit( 2 );
		}
		
		return brain;
	}
}
	