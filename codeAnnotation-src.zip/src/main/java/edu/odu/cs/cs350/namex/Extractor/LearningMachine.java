package edu.odu.cs.cs350.namex.Extractor;

import java.io.Serializable;

public class LearningMachine implements Serializable {

	/**
	 * Default serialVersionUID for serialization.
	 */
	private static final long serialVersionUID = 1L;


	
	

}
