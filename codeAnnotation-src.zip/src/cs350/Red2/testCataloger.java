package cs350.Red2;

import static org.junit.Assert.*;

import org.junit.Test;

public class testCataloger {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
