package cs350.Red2;

import java.util.ArrayList;

public class Cataloger {

	private LearningMachine theBrain;		//The learning machine
	private ArrayList<String[]> nameList;	//An ArrayList to store identified personal names
	
    /**
     * Constructor, default to a cataloger with a new learning machine and a empty nameList.
     **/
	public Cataloger (){							
		theBrain = new LearningMachine();
		nameList = new ArrayList<String[]>();
	}
	
	 /**
     * Constructor, create a cataloger with a pre-built learning machine and a empty nameList.
     * 
     * @param lm: a pre-built learning machine
     **/
	public Cataloger(LearningMachine lm){							
		theBrain = lm;
		nameList = new ArrayList<String[]>();
	}
	
    /**
     * Search through given text for personal names, classify them, and add the names to an ArrayList
     * 
     * 
     *  @param text: 
     **/
	public void identifyNamesIn (String text){ 
		
		/**
		 * 	text would have to be converted into instances of data for the lm, may want to make a new function for better readability
		 *  String[] wordList = text.split(" "); splits words into a new array based on spaces, may need to change split criteria or process it further later. May be useful for building instances for lm from text
		 *  
		**/
		
		
		 //for(int i = 0; i < wordList.length(); i++)
		 //		if(wordList[i] == personalName) nameList.add(wordList[i]);	Placeholder if statement, should be a classification by the lm
		 
	}
	
    /**
     *  Trains the learning machine using examples provided by trainer
     *  May end up removing this? Seeing as the trainer class handles the training.
     *  @param example:
     **/
	public void training (String example){ 			
		

	}

}
