/**
 * [ ] Implement Weka object in this class
 * [ ] As a dev, I'd like to have an interface that accepts a string that contain an authors name and return the that author's name.
 * [ ] As a dev, I'd like to train the Learning Machine using a Weka .arff file.
 */

package edu.odu.cs.cs350.namex.Extractor;

import weka.core.Instances;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Trainer {
	private LearningMachine theBrain;
	
    /**
     * Constructor, default to a Trainer with a new learning machine.
     **/
	public Trainer (){							
		theBrain = new LearningMachine();
	}
	
    /**
     * A get function to retrieve the learning machine.
     * @Return Trainer's learning machine.
     **/
	public LearningMachine getLearningMachine(){
		return theBrain;
	}	
	
    /**
     *
     **/
	public void prepareTrainingMaterials(){
		
		
	}

    /**
     * 
     * 
     **/
	public void train(){
		
	}
	


    /**
     * Load a Weka .arff file.
     *
     * @param filePath: Absolute path to the .arff file.
     **/
    public void loadTrainingFile(String filePath) throws FileNotFoundException, IOException{
       Instances dataset = new Instances(new BufferedReader(new FileReader(filePath)));     // load the training file

        // Store training dataset into Learning Machine obj
    }

    /**
     * Load individual training instances.
     * 
     * @param attributes:  
     **/
    public void loadTrainingText(String[] attributes){
    }
    
}
