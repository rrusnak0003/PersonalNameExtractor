/**
 * [ ] Implement Weka object in this class
 * [ ] As a dev, I'd like to have an interface that accepts a string that contain an authors name and return the that author's name.
 * [ ] As a dev, I'd like to train the Learning Machine using a Weka .arff file.
 */

package cs350.Red2;

import weka.core.Instances;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Trainer {
	private LearningMachine theBrain = new LearningMachine();
	
    /**
     *
     **/
	public void prepareTrainingMaterials(){
	}

    /**
     * 
     *  @param lm:
     **/
	public void train(LearningMachine lm){
		
	}

    /**
     * Load a Weka .arff file.
     *
     * @param filePath: Absolute path to the .arff file.
     **/
    public void loadTrainingFile(String filePath) throws FileNotFoundException, IOException{
        Instances dataset = new Instances(new BufferedReader(new FileReader(filePath)));     // load the training file

        // Store training dataset into Learning Machine obj
    }

    /**
     * Load individual training instances.
     * 
     * @param attributes:  
     **/
    public void loadTrainingText(String[] attributes){
    }
}
