package cs350.Red2;

public class LearningMachine {

}
