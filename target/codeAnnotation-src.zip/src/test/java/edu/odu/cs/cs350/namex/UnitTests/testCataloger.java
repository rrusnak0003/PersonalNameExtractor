package edu.odu.cs.cs350.namex.UnitTests;

import static org.junit.Assert.*;

import org.junit.Test;

public class testCataloger {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
