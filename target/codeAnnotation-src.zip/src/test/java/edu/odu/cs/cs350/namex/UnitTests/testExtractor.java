package edu.odu.cs.cs350.namex.UnitTests;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import org.junit.Test;
import edu.odu.cs.cs350.namex.Extractor.*;;

public class testExtractor {

	@Test
	public void testMain() {
		File tempFile = null;
		try {
			tempFile = File.createTempFile("tempLearningMachine",".ser");
		} catch (IOException e) {
            System.err.println( "Error: " + tempFile + " could not be opened" );
            System.exit( 2 );
		}
		tempFile.delete();
		
		assertTrue(tempFile.delete());
	}

	@Test
	public void testMarkPersonalNames() {
		String[] nameList = {"John Edward", "Dolly Breu's", "George Jackson"};
		String textBlock = "John Edward went to Dolly Breu's house and had a cup of tea with George Jackson.";
		
		String markedUp = Extractor.markPersonalNames(textBlock);
		
		assertEquals(markedUp,
				"<PER>John Edward</PER> went to <PER>Dolly Breu's</PER> house and had a cup of tea with <PER>George Jackson</PER>.");

	}
}
